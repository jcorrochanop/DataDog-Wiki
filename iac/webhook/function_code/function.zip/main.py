import base64
import json
from googleapiclient.discovery import build
import google.auth

PROJECT_ID = "balmy-mile-452912-p6"
CLUSTER = "my-datadog-cluster"
ZONE = "us-south1-b"
DEPLOYMENT = "mi-nginx"
NAMESPACE = "default"  

def main(request):
    try:
        data = request.get_json()
        # Aquí puedes filtrar por tipo de alerta, mensaje...
        print(f"Payload recibido: {json.dumps(data)}")

        # Auth para usar la API de Kubernetes Engine
        credentials, _ = google.auth.default()
        service = build('container', 'v1', credentials=credentials)
        # Obtener credenciales del cluster GKE
        cluster_info = service.projects().zones().clusters().get(
            projectId=PROJECT_ID,
            zone=ZONE,
            clusterId=CLUSTER
        ).execute()
        endpoint = 'https://' + cluster_info['endpoint']
        ca_cert = base64.b64decode(cluster_info['masterAuth']['clusterCaCertificate'])

        # Escalar el deployment usando kubernetes API
        from kubernetes import client, config
        configuration = client.Configuration()
        configuration.host = endpoint
        configuration.verify_ssl = True
        configuration.ssl_ca_cert = ca_cert
        config.load_kube_config_from_dict(configuration.__dict__)
        # Aumentar replicas
        api = client.AppsV1Api()
        scale = api.read_namespaced_deployment_scale(DEPLOYMENT, NAMESPACE)
        scale.spec.replicas = scale.spec.replicas + 1  
        api.replace_namespaced_deployment_scale(DEPLOYMENT, NAMESPACE, scale)
        return "OK", 200

    except Exception as e:
        print(f"ERROR: {e}")
        return str(e), 500
